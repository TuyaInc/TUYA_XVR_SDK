#ifndef __TUYA_MD_DEMO_H_
#define __TUYA_MD_DEMO_H_
#include <stdio.h>

void *thread_md_proc(void *arg);

#endif
