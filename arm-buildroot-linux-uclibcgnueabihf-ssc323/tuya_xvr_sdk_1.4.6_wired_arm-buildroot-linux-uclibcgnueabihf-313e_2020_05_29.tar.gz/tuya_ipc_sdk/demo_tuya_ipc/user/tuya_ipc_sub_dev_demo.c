#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#include "tuya_cloud_base_defs.h"
#include "tuya_iot_com_api.h"
#include "tuya_iot_base_api.h"
#include "tuya_ipc_sub_dev.h"
#include "tuya_ipc_common_demo.h"

/* recv add sub device cmd */
BOOL_T ty_gw_subdev_add_dev(IN CONST GW_PERMIT_DEV_TP_T tp,
                            IN CONST BOOL_T permit, IN CONST UINT_T timeout)
{
    USER_DEV_DTL_DEF_T uddd = 1;
    CHAR_T id[64];
    CHAR_T key[64];
    CHAR_T version[8];

    PR_DEBUG("tp: %d, permit: %d, timeout: %d\n", tp, permit, timeout);
#if defined(ENABLE_NVR) && (ENABLE_NVR==1)
    //need user todo nothing
#else
//user todo  get sub dev info
// user_sub_dev_bind_func();
/* set id  key  version*/
//end
    OPERATE_RET ret = tuya_iot_gw_bind_dev(tp, uddd, id, key, version);
    if(ret < 0) {
        PR_ERR("bind device error\n");
    }
#endif
    return TRUE;
}

VOID ty_gw_subdev_del_dev(IN CONST CHAR_T *pdevId)
{
    if(pdevId == NULL) {
        return;
    }

    PR_DEBUG("dev_id: %s\n", pdevId);

#if defined(ENABLE_NVR) && (ENABLE_NVR==1)
    //need user todo nothing
#else
//user todo unbind things
// user_sub_dev_unbind_func();
//endif
    OPERATE_RET ret = tuya_iot_gw_unbind_dev(pdevId);
    if(ret < 0) {
        PR_ERR("unbind device fail\n");
    }else{
        //unbind proc
        PR_DEBUG("devId[%s] stop sdk func\n",pdevId);
        ty_sub_dev_sdk_stop((char *)pdevId);
    }
#endif
    return;
}
OPERATE_RET ty_gw_subdev_grp_inform_dev(IN CONST GRP_ACTION_E action,IN CONST CHAR_T *dev_id,IN CONST CHAR_T *grp_id)
{
    PR_DEBUG("dev_id: %s cb\n", dev_id); 
    return 0;
}


OPERATE_RET ty_gw_subdev_scene_inform_dev(IN CONST SCE_ACTION_E action,IN CONST CHAR_T *dev_id,IN CONST CHAR_T *grp_id,IN CONST CHAR_T *sce_id)
{
    PR_DEBUG("dev_id: %s cb\n", dev_id); 
    return 0;

}

VOID ty_gw_subdev_inform_dev(IN CONST CHAR_T *dev_id, IN CONST OPERATE_RET op_ret)
{
    PR_DEBUG("dev_id: %s ret[%d]\n", dev_id, op_ret);  
#if defined(ENABLE_NVR) && (ENABLE_NVR==1)
        //need user todo nothing
#else
    if (OPRT_OK == op_ret){
        PR_DEBUG("start dev[%s] sdk business\n",dev_id);
        ty_sub_dev_sdk_start((char *)dev_id);
    }
#endif
    return ;
}



VOID ty_gw_dev_reset_ifm(IN CONST CHAR_T *pdevId, IN DEV_RESET_TYPE_E type)
{
    if(pdevId == NULL) {
        return;
    }

    PR_DEBUG("dev_id: %s, type: %d\n", pdevId, type);

    if(type == DEV_REMOTE_RESET_FACTORY) {

    } else if (type == DEV_RESET_DATA_FACTORY) {

    }

    return;
}


int ty_sub_dev_sdk_start(char * devId)
{
    PR_DEBUG("sub dev [%s] bind\n",devId);
    if (OPRT_OK != tuya_ipc_sub_dev_bind((char *)devId)){
        PR_DEBUG("devId[%s] sub dev bind failed\n",devId);  
        return -1;
    }

    //ringbuffer init
    PR_DEBUG("sub dev [%s] ring buffer init\n",devId);
    TUYA_APP_Init_Ring_Buffer((char *)devId);
    //local stor start here
    PR_DEBUG("sub dev [%s] stor start\n",devId);
    //test fake send av info to ringbuffer, user can do it 
    TUYA_APP_fake_video_start(devId);

    return 0;
}

int ty_sub_dev_sdk_stop(char * devId)
{

    TUYA_APP_fake_video_stop(devId);    

    PR_DEBUG("sub dev [%s] ring buffer init\n",devId);
    TUYA_APP_UnInit_Ring_Buffer((char *)devId);

    //devId unbind
    if (OPRT_OK != tuya_ipc_sub_dev_unbind((char *)devId)){
        PR_ERR("devId[%s] sub dev unbind failed");  
        return -1;
    }

    return 0;
}

int ty_sub_list_init()
{
    VOID *iterator = NULL;
    DEV_DESC_IF_S *dev_if = NULL;

    PR_DEBUG("__begin\n");
    do{
        dev_if = (DEV_DESC_IF_S *)tuya_iot_dev_traversal(&iterator);
        if((NULL != dev_if) && (TRUE == dev_if->bind))
        {
            PR_DEBUG("sub list devId[%s] vir_id[%s]\n",dev_if->id,dev_if->vir_id);  
            ty_sub_dev_sdk_start((char *)dev_if->id);

        }
    }while(dev_if); 

    return 0;
}

void fresh_dev_hb(void * args)
{
    char * dev_id = (char *)args;

    if (NULL == dev_id){
        return;
    }
    int is_online = 1;
    //if check online
    if (1 == is_online){
        tuya_iot_fresh_dev_hb(dev_id);
    }

    free(dev_id);

    return ;
}
void ty_dev_heartbeat_send_cb(const char *dev_id)
{
    //if dev no hb, IOT will callback 3times
    //todo 
    //user need do it async
    char * tmp = (char *)malloc(strlen(dev_id)+1);
    if (NULL == tmp){
        PR_ERR("malloc failed");
        return ;
    }
    memcpy(tmp, dev_id, strlen(dev_id));
    tmp[strlen(dev_id)] = 0;
    pthread_t pid = -1;
    if (0 != pthread_create(&pid, NULL, fresh_dev_hb, (void *)tmp)){
        PR_ERR("pthread create failed");
        free(tmp);
    } 
    return;
}

void TUYA_APP_Enable_HB()
{
    if (OPRT_OK != tuya_iot_sys_mag_hb_init(ty_dev_heartbeat_send_cb)){
        PR_ERR("init hb failed");
    }
    //set dev hb cb timeout
    //for(;;) traver sub dev, 
    //tuya_iot_set_dev_hb_timeout(devid, 60);
    int i = 0;
    for (i = 0; i < NVR_SUB_DEV_NUM; i++){
        CHAR_T devId[64];
        memset(devId,0x00, sizeof(devId));
        if (OPRT_OK == tuya_ipc_sub_dev_get_devId_4_CVI(i, devId,sizeof(devId))){
            tuya_iot_set_dev_hb_timeout(devId, 60);
        }
    }
    return ;
}

