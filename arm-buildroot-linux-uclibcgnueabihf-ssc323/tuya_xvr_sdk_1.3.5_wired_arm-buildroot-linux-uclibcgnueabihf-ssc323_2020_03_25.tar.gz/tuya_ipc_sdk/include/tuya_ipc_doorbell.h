#ifndef __TUYA_IPC_DOORBELL_H__
#define __TUYA_IPC_DOORBELL_H__

#ifdef __cplusplus
extern "C" {
#endif
#include "tuya_cloud_types.h"
#include "tuya_cloud_error_code.h"
#include "tuya_ipc_media.h"


#define MAX_MESSAGE_TIME 6


OPERATE_RET tuya_ipc_doorbell_init(IPC_MEDIA_INFO_S *media_setting, AES_HW_CBC_FUNC *aes_func);

OPERATE_RET tuya_ipc_doorbell_uninit();

OPERATE_RET tuya_ipc_doorbell_record_start(CHAR_T *extra_data, INT_T data_len);

OPERATE_RET tuya_ipc_doorbell_record_stop();


#ifdef __cplusplus
}
#endif

#endif


