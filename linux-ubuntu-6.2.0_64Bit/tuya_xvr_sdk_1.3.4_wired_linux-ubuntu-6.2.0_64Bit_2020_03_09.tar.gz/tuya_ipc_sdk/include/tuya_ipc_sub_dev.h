#ifndef _TUYA_IPC_SUB_DEV_H_
#define _TUYA_IPC_SUB_DEV_H_

#include "tuya_cloud_com_defs.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    E_CHANNEL_V_MAIN = 0,    
    E_CHANNEL_V_2RD,
    E_CHANNEL_V_3RD,
    E_CHANNEL_A_MAIN,
    E_CHANNEL_A_2RD,
    E_CHANNEL_AV_MAX,
}RING_CHANNEL_E;

typedef enum
{
    E_EVENT_CMD_NONE = 0,
    E_EVENT_CMD_PIR_START,
    E_EVENT_CMD_PIR_STOP,
    E_EVENT_CMD_MD_START,
    E_EVENT_CMD_MD_STOP,
    E_EVENT_CMD_MDPIR_START,
    E_EVENT_CMD_MDPIR_STOP,
    E_EVENT_CMD_FACE_START,
    E_EVENT_CMD_FACE_STOP,
    E_EVENT_CMD_BODY_START,
    E_EVENT_CMD_BODY_STOP = 10,
    E_EVENT_CMD_MAX,
}SUB_DEV_EVENT_CMD_E;

typedef enum
{
    E_MOD_P2P = 0,
    E_MOD_CHROMECAST,
    E_MOD_ECHOSHOW,
    E_MOD_MAX,
}MODULE_INDEX_E;
    
/**
 * \fn tuya_ipc_sub_dev_bind(IN CHAR_T * devId)
* \brief sub dev bind
* \param[in] devId sub dev flag
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_bind(IN CHAR_T * devId);

/**
 * \fn tuya_ipc_sub_dev_unbind(IN CHAR_T * devId)
* \brief cancle sub dev bind
* \param[in] devId sub dev flag
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_unbind(IN CHAR_T * devId);

/**
 * \fn tuya_ipc_get_ring_chn_id(IN CHAR_T * devId)
* \brief get ring chn info of sub dev
* \param[in] devId sub dev flag
* \param[in] chn for video or audio
* \param[OUT] real stor Id in ring buffer
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_get_ring_chn_id(IN CHAR_T * devId, IN RING_CHANNEL_E chn, OUT INT_T * pId);

/**
 * \fn tuya_ipc_sub_dev_set_pw(IN CHAR_T * devId, IN CHAR_T * pw)
* \brief set p2p passwd to sub dev
* \param[in] virId sub dev from cloud
* \param[in] pw :p2p passwd
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_set_pw(IN CHAR_T * devId, IN CHAR_T * pw);
/**
 * \fn tuya_ipc_sub_dev_get_pw(IN CHAR_T * devId, OUT CHAR_T * pw, IN INT_T pwLen)
* \brief get p2p passwd to sub dev
* \param[in] virId sub dev from cloud
* \param[out] pw :p2p passwd
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_get_pw(IN CHAR_T * devId, OUT CHAR_T * pw, IN INT_T pwLen);

OPERATE_RET tuya_ipc_sub_dev_update_time(IN CHAR_T * devId, IN UINT_T time);

OPERATE_RET tuya_ipc_sub_dev_get_time(IN CHAR_T * devId, OUT UINT_T * pTime);

/**
 * \fn tuya_ipc_sub_dev_set_event_cmd(IN CHAR_T * devId, IN SUB_DEV_EVENT_CMD_E cmd, UINT_T  pTime)
* \brief set event cmd to sub dev
* \param[in] devId sub dev flag
* \param[in] cmd
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_set_event_cmd(IN CHAR_T * devId, IN SUB_DEV_EVENT_CMD_E cmd,IN UINT_T time);

/**
 * \fn tuya_ipc_sub_dev_get_event_cmd(IN CHAR_T * devId, OUT UINT_T * pCmd,OUT UINT_T * pTime)
* \brief set event cmd to sub dev
* \param[in] devId sub dev flag
* \param[out] pCmd:bits for event stat
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_get_event_cmd(IN CHAR_T * devId, OUT UINT_T * pCmd,OUT UINT_T * pTime);

/**
 * \fn tuya_ipc_sub_dev_set_virual_id(IN CHAR_T * devId, IN CHAR_T * virId);
* \brief set vir id for deviD
* \param[in] devId sub dev flag
* \param[in] virId vir devId from cloud
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_set_virual_id(IN CHAR_T * devId, IN CHAR_T * virId);

    
/**
 * \fn tuya_ipc_sub_dev_get_virual_id(IN CHAR_T * devId, IN CHAR_T * virId);
* \brief set vir id for deviD
* \param[in] devId sub dev flag
* \param[in] len :len of virId
* \param[out] virId vir devId from cloud
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_get_virual_id(IN CHAR_T * devId, INOUT CHAR_T * virId, IN INT_T len);

/**
 * \fn tuya_ipc_sub_dev_check_alive(IN CHAR_T * devId)
* \brief check devId is alive
* \param[in] devId sub dev flag
* \param[in] 
* \return OPERATE_RET
 */
OPERATE_RET tuya_ipc_sub_dev_check_alive(IN CHAR_T * devId);

OPERATE_RET tuya_ipc_sub_dev_set_alive(IN CHAR_T * devId, IN BOOL_T enable);

/***********************************************************
*  Function: tuya_ipc_sub_dev_bind_4_CVI
*  Desc:     bind sub-device to gateway
*  Input:    tp: sub-device type
*  Input:    uddd: sub-device detail type
*  Input:    num: sub device num of dvr/nvr
*  Input:    pk: sub-device product key
*  Input:    ver: sub-device version
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_ipc_sub_dev_bind_4_CVI(IN CONST GW_PERMIT_DEV_TP_T tp,IN CONST USER_DEV_DTL_DEF_T uddd,IN CONST INT_T dev_cnt, IN CONST CHAR_T * pk, IN CONST CHAR_T * ver);

/***********************************************************
*  Function: tuya_ipc_sub_dev_get_chn_4_CVI
*  Desc:     get chn of CVI
*  Input:    devId: devId of CVI
*  Output:   pChn: chn
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_ipc_sub_dev_get_chn_4_CVI(IN CONST CHAR_T * devId, OUT INT_T * pChn);

/***********************************************************
*  Function: tuya_ipc_sub_dev_unbind_4_CVI
*  Desc:     unbind all sub dev
*  Input:    none
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_ipc_sub_dev_unbind_4_CVI();

/***********************************************************
*  Function: tuya_ipc_sub_dev_get_devId_4_CVI
*  Desc:     get devId by chn
*  Input:    chn: channel Id
*  Output:   devId: chn->devId
*  Input:    len: devId len
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_ipc_sub_dev_get_devId_4_CVI(IN CONST INT_T chn, OUT CHAR_T * devId,IN CONST INT_T len);

/***********************************************************
*  Function: tuya_ipc_sub_dev_binds_4_CVI
*  Desc:     bind all sub-device to gateway
*  Input:    tp: sub-device type
*  Input:    uddd: sub-device detail type
*  Input:    num: sub device num of dvr/nvr
*  Input:    pk: sub-device product key
*  Input:    ver: sub-device version
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_ipc_sub_dev_binds_4_CVI(IN CONST GW_PERMIT_DEV_TP_T tp,IN CONST USER_DEV_DTL_DEF_T uddd,IN CONST INT_T dev_cnt, IN CONST CHAR_T * pk, IN CONST CHAR_T * ver);

/***********************************************************
*  Function: tuya_ipc_sub_dev_unbind_4_CVI
*  Desc:     unbind all sub dev
*  Input:    none
*  Return:   OPRT_OK: success  Other: fail
***********************************************************/
OPERATE_RET tuya_ipc_sub_dev_unbinds_4_CVI();

#ifdef __cplusplus
}
#endif

#endif /*_TUYA_IPC_SUB_DEV_H_*/

