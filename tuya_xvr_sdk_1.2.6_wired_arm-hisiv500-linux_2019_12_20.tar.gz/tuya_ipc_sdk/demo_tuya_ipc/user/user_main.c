#include <sys/time.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#include "tuya_iot_com_api.h"
#include "tuya_iot_base_api.h"
#include "tuya_ipc_dp_utils.h"
#include "tuya_ipc_cloud_storage.h"
#include "tuya_ipc_common_demo.h"
#include "tuya_ipc_system_control_demo.h"
#include "tuya_ipc_media_demo.h"
#include "tuya_ipc_motion_detect_demo.h"
#include "tuya_ipc_sub_dev_demo.h"

#define IPC_APP_STORAGE_PATH    "/tmp/"   //Path to save sdk cfg ,need to read and write, doesn't loss when poweroff 
#define IPC_APP_UPGRADE_FILE    "/tmp/upgrade.file" //Path to save upgrade file when OTA upgrading
#define IPC_APP_SD_BASE_PATH    "/tmp/"      // SD Card Mount Directory,Local Storage Root Directory
#define IPC_APP_PID             "tuyaOnePidForOneDevice"  //PID is Product ID of TUYA device。
                                                    //This is demo-specific, informal. Formal ID Creates Product Generation on Graffiti Developer Platform 
#define IPC_APP_UUID            "tuyaOneUuidForOneDevice" //UUID is the unique identification of each device
                                                          //Please apply for TUYA in development and production 
#define IPC_APP_AUTHKEY         "tuyaOneAuthForOneDevice" //AUTHKEY is the authentication codes corresponding to UUID, one machine one code, paired with UUID. 
#define IPC_APP_VERSION         "1.0.0"     //Firmware version information displayed on TUYA APP 

#define NVR_SUB_DEV_NUM         (4)     //sub dev num
#define IPC_APP_SUB_DEV_PID      "tuyaOneSubPidForOneDevice"  //PID is Product ID of TUYA sub device。
#define IPC_APP_SUB_DEV_VERSION  "1.0.0"     //Firmware version information displayed on TUYA sub dev 

IPC_MGR_INFO_S s_mgr_info = {0};
STATIC INT_T s_mqtt_status = 0;

CHAR_T s_raw_path[128] = {0};

STATIC VOID __IPC_APP_Get_Net_Status_cb(IN CONST BYTE_T stat)
{
    PR_DEBUG("Net status change to:%d", stat);
    switch(stat)
    {
#if defined(WIFI_GW) && (WIFI_GW==1)
        case STAT_CLOUD_CONN:        //for wifi ipc
#else
        case GB_STAT_CLOUD_CONN:     //for wired ipc
#endif
        {
            IPC_APP_Notify_LED_Sound_Status_CB(IPC_MQTT_ONLINE);
            PR_DEBUG("mqtt is online\r\n");
            s_mqtt_status = 1;
            break;
        }
        default:
        {
            break;
        }
    }
}

#if defined(WIFI_GW) && (WIFI_GW==1)
OPERATE_RET IPC_APP_Init_SDK(WIFI_INIT_MODE_E init_mode, CHAR_T *p_token)
#else
OPERATE_RET IPC_APP_Init_SDK(VOID)
#endif
{
    PR_DEBUG("SDK Version:%s\r\n", tuya_ipc_get_sdk_info());

    memset(&s_mgr_info, 0, sizeof(IPC_MGR_INFO_S));
    strcpy(s_mgr_info.storage_path, IPC_APP_STORAGE_PATH);
    strcpy(s_mgr_info.upgrade_file_path, IPC_APP_UPGRADE_FILE);
    strcpy(s_mgr_info.sd_base_path, IPC_APP_SD_BASE_PATH);
    strcpy(s_mgr_info.product_key, IPC_APP_PID);
    strcpy(s_mgr_info.uuid, IPC_APP_UUID);
    strcpy(s_mgr_info.auth_key, IPC_APP_AUTHKEY);
    strcpy(s_mgr_info.dev_sw_version, IPC_APP_VERSION);
    s_mgr_info.max_p2p_user = 5; //TUYA P2P supports 5-way simultaneous preview, 
                                 //and developers can consider scaling down based on hardware resources.
    PR_DEBUG("Init Value.storage_path %s", s_mgr_info.storage_path);
    PR_DEBUG("Init Value.upgrade_file_path %s", s_mgr_info.upgrade_file_path);
    PR_DEBUG("Init Value.sd_base_path %s", s_mgr_info.sd_base_path);
    PR_DEBUG("Init Value.product_key %s", s_mgr_info.product_key);
    PR_DEBUG("Init Value.uuid %s", s_mgr_info.uuid);
    PR_DEBUG("Init Value.auth_key %s", s_mgr_info.auth_key);
    PR_DEBUG("Init Value.p2p_id %s", s_mgr_info.p2p_id);
    PR_DEBUG("Init Value.dev_sw_version %s", s_mgr_info.dev_sw_version);
    PR_DEBUG("Init Value.max_p2p_user %u", s_mgr_info.max_p2p_user);

    IPC_APP_Set_Media_Info();
    PR_DEBUG("IOT SDK Version: %s", tuya_iot_get_sdk_info());

    IPC_APP_Notify_LED_Sound_Status_CB(IPC_BOOTUP_FINISH);

    OPERATE_RET op_ret = tuya_iot_init(s_mgr_info.storage_path);
    if(OPRT_OK != op_ret) {
        PR_ERR("tuya_iot_init err: %d PATH: %s\n", op_ret, s_mgr_info.storage_path);
        return -1;
    }
    GW_PROD_INFO_S prod_info;
    prod_info.uuid = s_mgr_info.uuid;
    prod_info.auth_key = s_mgr_info.auth_key;
    op_ret = tuya_iot_set_gw_prod_info(&prod_info);
    if(OPRT_OK != op_ret) {
        PR_ERR("tuya_iot_set_gw_prod_info err: %d\n", op_ret);
        return -1;
    }
    /*gw init*/
    TY_IOT_CBS_S        iot_cbs;
    TY_IOT_GW_CBS_S     gw_cbk;
    GW_ATTACH_ATTR_T*   pattr = NULL;
    UINT_T              attr_num = 0;

    memset(&iot_cbs, 0, sizeof(TY_IOT_CBS_S));
    memset(&gw_cbk, 0, sizeof(TY_IOT_GW_CBS_S));

    iot_cbs.gw_status_cb    = IPC_APP_status_change_cb;
    iot_cbs.gw_ug_cb        = IPC_APP_Upgrade_Inform_cb;
    iot_cbs.gw_reset_cb     = IPC_APP_Reset_System_CB;
    iot_cbs.dev_obj_dp_cb   = IPC_APP_handle_dp_cmd_objs;
    iot_cbs.dev_raw_dp_cb   = IPC_APP_handle_dp_cmd_raw;
    iot_cbs.dev_dp_query_cb = IPC_APP_handle_dp_query_objs;
    
    iot_cbs.dev_ug_cb       = ty_gw_dev_ug_inform;
    iot_cbs.dev_reset_cb    = ty_gw_dev_reset_ifm;

    gw_cbk.gw_add_dev_cb    = ty_gw_subdev_add_dev;
    gw_cbk.gw_del_cb        = ty_gw_subdev_del_dev;
    gw_cbk.gw_dev_grp_cb    = ty_gw_subdev_grp_inform_dev;
    gw_cbk.gw_dev_scene_cb  = ty_gw_subdev_scene_inform_dev;
    gw_cbk.gw_ifm_cb        = ty_gw_subdev_inform_dev;

    op_ret = tuya_iot_gw_dev_init(&iot_cbs, &gw_cbk,s_mgr_info.product_key, s_mgr_info.dev_sw_version, pattr, attr_num);
    if(OPRT_OK != op_ret) {
        PR_ERR("tuya_iot_soc_init err: %d\n", op_ret);
        return -1;
    }
    /*end*/
    //set reqion info for qrcode 
    tuya_ipc_set_region(REGION_CN);
// set cb 
    op_ret = tuya_iot_reg_get_nw_stat_cb(__IPC_APP_Get_Net_Status_cb);
    if(OPRT_OK != op_ret) {
        PR_ERR("tuya_iot_reg_get_nw_stat_cb err: %d\n",op_ret);
        return -1;
    }
    
    return OPRT_OK;
}

VOID usage(CHAR_T *app_name)
{
    printf("%s -m mode -t token -r raw path -h\n", (CHAR_T *)basename(app_name));
    printf("\t m: 0-WIFI_INIT_AUTO 1-WIFI_INIT_AP 2-WIFI_INIT_DEBUG, refer to WIFI_INIT_MODE_E\n"
        "\t t: token get form qrcode info\n"
        "\t r: raw source file path\n"
        "\t h: help info\n");

    return;
}

#ifdef __HuaweiLite__
int app_main(int argc, char *argv[])
#else
int main(int argc, char *argv[])
#endif

{
    INT_T res = -1;
    CHAR_T token[30] = {0};
    WIFI_INIT_MODE_E mode = WIFI_INIT_AUTO;

    strcpy(s_raw_path, "/tmp"); //The directory where the test audio and video folders needed by demo are located 
#ifdef __HuaweiLite__
    if(argc != 2)
    {
        printf("%s <token>\n", argv[0]);
        return -1;
    }
    mode = WIFI_INIT_DEBUG; //The demo mode is set to debug, so before running this main process, 
                            //developers need to make sure that devices are connected to the Internet. 。
    strcpy(token, argv[1]); //Token field values scanned from APP QR-codes or broadcast packets
#else
    while((res = getopt(argc, argv, "?m:t:s:r:h")) != -1) 
    {
        switch(res) {
        case 'm':
            mode = atoi(optarg);
            break;

        case 't':
            strcpy(token, optarg);
            break;

        case 'r':
            strcpy(s_raw_path, optarg);
            break;

        case 'h':
        default:
            usage(argv[0]);
            return -1;
        }
    }
#endif
    /* Init SDK */
#if defined(WIFI_GW) && (WIFI_GW==1)
    IPC_APP_Init_SDK(mode, token);
#else
    //The token interaction with TUYA APP is implemented in SDK of wired equipment.
    IPC_APP_Init_SDK();
    //user need call once,before connect to tuya cloud
    IPC_APP_get_qrcode_info();
#endif

    /*Demo uses file simulate external audio and video input. 
    The actual data acquisition needs to be realized by developers. */

    /* whether SDK is connected to MQTT */
    while(s_mqtt_status != 1)
    {
        sleep(1);
    }
#if defined(ENABLE_NVR) && (ENABLE_NVR==1)
    /*bind all sub dev for nvr*/
    /* cost time depend on NVR_SUB_DEV_NUM*/
    USER_DEV_DTL_DEF_T uddd = (0x2 << 24);
    GW_PERMIT_DEV_TP_T tp = 0;
    tuya_ipc_sub_dev_bind_4_CVI(tp, uddd, NVR_SUB_DEV_NUM, IPC_APP_SUB_DEV_PID, IPC_APP_SUB_DEV_VERSION);

    //init ring buffer for user to append av frame    
    TUYA_APP_Init_Ring_Buffer();
    /*At least one system time synchronization after networking*/
    IPC_APP_Sync_Utc_Time();
    /* Enable the p2p */
    TUYA_APP_Enable_P2PTransfer(s_mgr_info.max_p2p_user);    

    /* Upload all local configuration item (DP) status when MQTT connection is successful */
    IPC_APP_upload_all_status_XVR();
    //sub dev heartbeat demo api
    TUYA_APP_Enable_HB();
    TUYA_APP_Enable_CloudStorage_4_NVR();
#endif
    /* Starting the detection tasks and trigger alarm reporting/local storage/cloud storage tasks through detection results  */
#ifdef __HuaweiLite__
    stappTask.pfnTaskEntry = (TSK_ENTRY_FUNC)thread_md_proc;
    stappTask.pcName = "motion_detect";
    LOS_TaskCreate((UINT32 *)&taskid, &stappTask);
#else
    pthread_t motion_detect_thread;
    pthread_create(&motion_detect_thread, NULL, thread_md_proc, NULL);
    pthread_detach(motion_detect_thread);
#endif

    /* Manual simulation of related functions */
    char test_input[64] = {0};
    extern int fake_md_status;
    while(1)
    {
        scanf("%s",test_input);
        /* Simulate the start of motion detection events */
        if(0 == strcmp(test_input,"start"))
        {
            fake_md_status = 1;
        }
        /* End of Simulated Event */
        else if(0 == strcmp(test_input,"stop"))
        {
            fake_md_status = 0;
        }
        /* Simulating with commands to get the device's activation status */
        else if(0 == strcmp(test_input,"status"))
        {
            IPC_REGISTER_STATUS status = tuya_ipc_get_register_status();
            printf("current register status %d[0:unregistered 1:registered 2:activated]\n",status);
        }
        /* Simulate with command to doorbell Report */
        else if(0 == strcmp(test_input,"bell"))
        {
            //Report the message and data of the doorbell 
            //Using file simulation, you can actually use the JPEG address and size obtained from the chip encoder.
            char snapfile[64];
            snprintf(snapfile,64,"%s/rawfiles/tuya_logo.jpg",s_raw_path);
            FILE*fp = fopen(snapfile,"r+");
            if(NULL == fp)
            {
                printf("fail to open snap.jpg\n");
                continue;
            }
            fseek(fp,0,SEEK_END);
            int snapshot_size = ftell(fp);
            char *snapshot_buf = (char *)malloc(snapshot_size);
            fseek(fp,0,SEEK_SET);
            fread(snapshot_buf,snapshot_size,1,fp);
            fclose(fp);
            /* Push the detection message and the current snapshot image to the APP . 
            Snapshot image acquisition needs to be implemented by the developer */
            tuya_ipc_notify_door_bell_press(snapshot_buf, snapshot_size, NOTIFICATION_CONTENT_JPEG);
            free(snapshot_buf);
        } else if (0 == strcmp(test_input, "suspend")) {
            TUYA_APP_LOW_POWER_ENABLE();
        }

        usleep(100*1000);
    }

    return 0;
}

