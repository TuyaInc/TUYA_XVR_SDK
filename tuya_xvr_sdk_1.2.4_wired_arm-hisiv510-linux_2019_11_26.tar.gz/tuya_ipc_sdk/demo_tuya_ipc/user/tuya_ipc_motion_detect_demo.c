/*********************************************************************************
  *Copyright(C),2015-2020, 
  *TUYA 
  *www.tuya.comm
  *FileName:    tuya_ipc_motion_detect_demo
**********************************************************************************/

#include <stdio.h>
#include "tuya_ipc_cloud_storage.h"
#include "tuya_ipc_multi_storage.h"
#include "tuya_ipc_api.h"


//AI detect should SUPPORT_AI_DETECT
#define SUPPORT_AI_DETECT 1
#if SUPPORT_AI_DETECT
#include "tuya_ipc_ai_detect_storage.h"
#endif

//According to different chip platforms, users need to implement whether there is motion alarm in the current frame.
int fake_md_status = 0;
int get_motion_status()
{
    //if motion detected ,return 1
    return fake_md_status;
    //else return 0
    //return 0;
}

//According to different chip platforms, users need to implement the interface of capture.
void get_motion_snapshot(char *snap_addr, int *snap_size)
{
    //we use file to simulate
    char snapfile[128];
    *snap_size = 0;
    extern char s_raw_path[];
    snprintf(snapfile,64,"%s/rawfiles/tuya_logo.jpg",s_raw_path);
    FILE*fp = fopen(snapfile,"r+");
    if(NULL == fp)
    {
        printf("fail to open snap.jpg\n");
        return;
    }
    fseek(fp,0,SEEK_END);
    *snap_size = ftell(fp);
    if(*snap_size < 100*1024)
    {
        fseek(fp,0,SEEK_SET);
        fread(snap_addr,*snap_size,1,fp);
    }
    fclose(fp);
    return;
}

#if SUPPORT_AI_DETECT
//According to different chip platforms, users need to implement the interface of capture.
VOID tuya_ipc_get_snapshot_cb(char* pjbuf, int* size)
{

}
#endif

VOID *thread_md_proc(VOID *arg)
{
    //todo
    //tuya_ipc_dev_notify_with_event_4_CVI(IN CONST INT_T chn, IN CONST CHAR_T *snap_buffer, IN CONST UINT_T snap_size, IN CONST NOTIFICATION_CONTENT_TYPE_E type, IN CONST NOTIFICATION_NAME_E name);
    return;
}

#if SUPPORT_AI_DETECT
extern IPC_MEDIA_INFO_S s_media_info;
OPERATE_RET TUYA_APP_Enable_AI_Detect()
{
    tuya_ipc_ai_detect_storage_init(&s_media_info);

    return OPRT_OK;
}
#endif
