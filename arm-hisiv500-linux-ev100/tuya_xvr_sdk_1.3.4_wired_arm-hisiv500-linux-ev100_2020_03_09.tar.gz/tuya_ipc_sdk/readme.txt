﻿文件说明：
include：应用相关头文件
demo_xxx：demo代码目录
	include：用户应用代码头文件，makefile会自动关联
	user：用户代码
libs: 涂鸦IPC库和P2P库，libz的参考库（此库为ubuntu版本）
特别说明：还需要一个libz的库，该库为开源库。需要用户根据自己的工具链进行编译。
请客户自行到https://superb-sea2.dl.sourceforge.net/project/libpng/zlib/1.2.11/zlib-1.2.11.tar.gz 此处进行下载
build_app.sh：用户应用代码编译脚本
	
编译说明：
1 打开Makefile文件，设置变量COMPILE_PREX ?= 具体交叉编译工具链的绝对路径
2 执行：sh build_app.sh demo_xxx wifi/wire ，完成编译