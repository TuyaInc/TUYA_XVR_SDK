#!/bin/sh

APP_BIN_NAME=
WIFI_IPC=0
if [ -z "$1" ];then
	echo "please input the target app name "
	exit 1
else
	APP_BIN_NAME=$1
fi

if [ -z "$2" ];then
    echo "please input the NET type [wifi/wired]"
    exit 1
fi

if [ "$2" = "wifi" ];then
	WIFI_IPC=1
elif [ "$2" = "wired" ];then
	WIFI_IPC=0
else
	echo "please input the right NET type [wifi/wired]"
    exit 1
fi

#开始编译APP
if [ -z "$3" ];then
    make APP_BIN_NAME=$APP_BIN_NAME WIFI_IPC=$WIFI_IPC build_app
else
    make APP_BIN_NAME=$APP_BIN_NAME WIFI_IPC=$WIFI_IPC COMPILE_PREX=$3 build_app
fi
