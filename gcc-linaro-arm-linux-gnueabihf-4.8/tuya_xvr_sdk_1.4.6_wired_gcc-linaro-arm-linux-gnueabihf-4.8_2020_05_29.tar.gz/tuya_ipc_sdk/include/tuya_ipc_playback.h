/*********************************************************************************
  *Copyright(C),2018, 涂鸦科技 www.tuya.comm
  *FileName:    tuya_ipc_multi_storage.h
**********************************************************************************/

#ifndef __TUYA_IPC_PLAY_BACK_H__
#define __TUYA_IPC_PLAY_BACK_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \brief 单个文件的时间戳信息
 * \struct SS_FILE_TIME_TS_S
 */
typedef struct
{
    UINT_T start_timestamp; /**< 回放文件开始时间戳（以秒为单位） */
    UINT_T end_timestamp;   /**< 回放文件结束时间戳（以秒为单位） */
} SS_FILE_TIME_TS_S;

/**
 * \struct SS_QUERY_DAY_TS_ARR_S
 */
typedef struct
{
    UINT_T file_count; /**< 当天有多少个回放文件 */
    SS_FILE_TIME_TS_S file_arr[0]; /**< 回放文件数组 */
} SS_QUERY_DAY_TS_ARR_S;

/**
 * \brief 回放事件
 * \struct SS_PB_EVENT_E
 */
typedef enum
{
    SS_PB_FINISH = 0, /**< 当前文件播放完毕 */
    SS_PB_NEWFILE,    /**< 找到连续文件，继续播放 */
}SS_PB_EVENT_E;

/**
 * \brief 回放状态
 * \struct SS_PB_STATUS_E
 */
typedef enum
{
    SS_PB_MUTE, /**< 静音 */
    SS_PB_UN_MUTE, /**< 取消静音 */
    SS_PB_PAUSE, /**< 暂停 */
    SS_PB_RESUME,/**< 继续 */
}SS_PB_STATUS_E;

/**
 * \typedef SS_PB_EVENT_CB
 * \brief 回放事件回调函数定义
 * \param[in] pb_idx 回放事务ID
 * \param[in] pb_event 回放事件ID
 * \param[in] args 额外参数
 */
typedef VOID (*PB_EVENT_CB)(IN CHAR_T *devId,IN UINT_T pb_idx, IN SS_PB_EVENT_E pb_event, IN PVOID_T args);
/**
 * \typedef SS_PB_GET_MEDIA_CB
 * \brief 回放数据获取定义
 * \param[in] pb_idx 回放事务ID
 * \param[in] p_frame 回放数据
 */
typedef VOID (*PB_GET_MEDIA_CB)(IN CHAR_T *devId, IN UINT_T pb_idx, IN CONST MEDIA_FRAME_S *p_frame);

OPERATE_RET tuya_ipc_pb_query_by_month(CHAR_T * devId, IN UINT_T pbIdx, IN USHORT_T year, IN USHORT_T month, OUT UINT_T *pDays);
OPERATE_RET tuya_ipc_pb_query_by_day(CHAR_T * devId, IN UINT_T pbIdx, IN USHORT_T year, IN USHORT_T month, IN UCHAR_T day,
                                      OUT SS_QUERY_DAY_TS_ARR_S **ppTsArr);
OPERATE_RET tuya_ipc_pb_start(IN CHAR_T *devId, IN UINT_T pbIdx, IN PB_EVENT_CB event_cb, IN PB_GET_MEDIA_CB video_cb, IN PB_GET_MEDIA_CB audio_cb);
OPERATE_RET tuya_ipc_pb_seek(IN CHAR_T *devId, IN UINT_T pbIdx, IN SS_FILE_TIME_TS_S *pbSect, IN UINT_T startTimeS);
OPERATE_RET tuya_ipc_pb_stop(IN CHAR_T *devId, IN UINT_T pbIdx);
OPERATE_RET tuya_ipc_ss_pb_set_status(IN CHAR_T *devId, IN UINT_T pbIdx, IN SS_PB_STATUS_E status);


#ifdef __cplusplus
}
#endif

#endif

