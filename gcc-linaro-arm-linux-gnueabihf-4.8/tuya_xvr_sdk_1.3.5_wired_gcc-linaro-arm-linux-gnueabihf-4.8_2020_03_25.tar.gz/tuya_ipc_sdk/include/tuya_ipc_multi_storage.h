/*********************************************************************************
  *Copyright(C),2019, www.tuya.comm
  *FileName:    tuya_ipc_p2p.h
**********************************************************************************/

#ifndef __TUYA_IPC_MULTI_STORAGE_H__
#define __TUYA_IPC_MULTI_STORAGE_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "tuya_ipc_media.h"

#define STOR_HD_MAX_CHN     (16)
#define STOR_HD_MAX_IFRAME_PRE_FMT     (1024*2)
#define STOR_HD_DEVICE_LEN  (64)
#define STOR_HD_ENCKEY_LEN  (32)
#define STOR_HD_ENCIV_LEN  (32)

#define STOR_HD_O_SYNC       (0x1)
#define STOR_HD_O_RDWR       (0x2)
#define STOR_HD_O_RD         (0x3)

typedef INT_T (* STOR_HD_OPEN_CB)(IN CONST BYTE_T * pHdName, IN CONST UINT_T fileType, IN CONST UINT_T fileNo, IN CONST INT_T mode, PVOID_T attr);
typedef INT_T (* STOR_HD_WRITE_CB)(IN CONST PVOID_T hdHandle,IN CONST UINT64_T uOffset, IN CONST BYTE_T * pBuff, IN CONST UINT_T writeLen, PVOID_T attr);
typedef INT_T (* STOR_HD_READ_CB)(IN CONST PVOID_T hdHandle,IN CONST UINT64_T uOffset, IN BYTE_T * pBuff, IN CONST UINT_T readLen, PVOID_T attr);
typedef INT_T (* STOR_HD_SEEK_CB)(IN CONST PVOID_T hdHandle,IN CONST UINT64_T uOffset, IN CONST INT_T whence, PVOID_T attr);
typedef INT_T (* STOR_HD_FLUSH_CB)(IN CONST PVOID_T hdHandle,PVOID_T attr);
typedef INT_T (* STOR_HD_CLOSE_CB)(IN CONST PVOID_T hdHandle,PVOID_T attr);

typedef struct {
    STOR_HD_OPEN_CB stor_hd_open;
    STOR_HD_WRITE_CB stor_hd_write;
    STOR_HD_READ_CB stor_hd_read;
    STOR_HD_SEEK_CB stor_hd_seek;
    STOR_HD_FLUSH_CB stor_hd_flush;
    STOR_HD_CLOSE_CB stor_hd_close;
}STOR_HD_OPERATE_CB;

typedef enum
{
    HDD_STATUS_UNKNOWN = 0,
    HDD_STATUS_NORMAL,
    HDD_STATUS_ABNORMAL,
    HDD_STATUS_LACK_SPACE,
    HDD_STATUS_FORMATING,
    HDD_STATUS_NOT_EXIST,
    HDD_STATUS_MAX
}E_HDD_STATUS;

typedef enum {
    STOR_HD_AV_EVENT = 0,   //normal video
    STOR_HD_MD_EVENT,       //md detect
    STOR_HD_FACE_EVENT,
    STOR_HD_BODY_EVENT,
    STOR_HD_MAX_EVENT,
}STOR_HD_EVENT_TYPE_E;

typedef struct {
    BYTE_T hdName[STOR_HD_DEVICE_LEN];
    INT_T  hdType;      //tf hdd type
    UINT64_T hdStartOffset;   //可读写起始偏移
    UINT64_T hdTotolLen;      //总大小
    STOR_HD_OPERATE_CB strHdOpCb;   //操作回调
}STOR_HD_INIT_INFO_T;


typedef enum
{
    E_STOR_IDLE,
    E_STOR_STOP,
    E_STOR_START,
    E_STOR_RUNNIG,
    E_STOR_RESTART,
    E_STOR_MAX_STAT,
}STOR_STATUS_E;

/***********************************************************
*  Function: tuya_ipc_stor_init
*  Note:  stor init 
*  Input: param input hdd info
*  Output: none
*  Return: 
***********************************************************/
OPERATE_RET tuya_ipc_stor_init(STOR_HD_INIT_INFO_T *param);

OPERATE_RET tuya_ipc_stor_uninit();

/***********************************************************
*  Function: tuya_ipc_stor_start
*  Note:  local stor start
*  Input: pMedia:media info of devId
*  Output: none
*  Return: 
***********************************************************/
OPERATE_RET tuya_ipc_stor_start(IN CONST CHAR_T * devId, IN CONST IPC_MEDIA_INFO_S *pMedia);

/***********************************************************
*  Function: tuya_ipc_stor_stop
*  Note:  local stor stop
*  Input: 
*  Output: none
*  Return: 
***********************************************************/
OPERATE_RET tuya_ipc_stor_stop(IN CONST CHAR_T * devId);

/***********************************************************
*  Function: tuya_ipc_stor_set_stat
*  Note:  set stor status of devId
*  Input: devId  stat:start or stop or restart  type:event trigger type
*  Output: none
*  Return: 
***********************************************************/
OPERATE_RET tuya_ipc_stor_set_stat(IN CONST CHAR_T * devId, IN CONST STOR_STATUS_E stat, IN CONST STOR_HD_EVENT_TYPE_E type);

/***********************************************************
*  Function: tuya_ipc_stor_get_stat
*  Note:  get stor status of devId
*  Input: devId  stat:start or stop or restart  type:event trigger type
*  Output: none
*  Return: 
***********************************************************/
OPERATE_RET tuya_ipc_stor_get_stat(IN CONST CHAR_T * devId, OUT STOR_STATUS_E * pStat, OUT STOR_HD_EVENT_TYPE_E * pType);

/***********************************************************
*  Function: tuya_ipc_stor_get_volume
*  Note:  get volume of hdd
*  Input: 
*  Output: 
*  Return: 
***********************************************************/
OPERATE_RET tuya_ipc_stor_get_volume(STOR_HD_INIT_INFO_T *param, OUT UINT64_T * totol, OUT UINT64_T * free);

//for test
OPERATE_RET tuya_ipc_stor_trans_test(IN CONST CHAR_T * devId);


//api of search part
typedef struct {
    INT_T fd;
    INT_T type;
    INT_T blockNo; /* file number in the partition */
    INT_T segNo; /* segment number in the file */  
    UINT64_T curRdPos;
    UINT64_T startTime;
    UINT64_T endTime;
    UINT64_T startOffset;
    UINT64_T endOffset;
}STOR_HD_SEARCH_HANDLE;

typedef struct {
    UINT16_T blockNo;
    UINT16_T segNo; 
    UINT64_T startTime;
    UINT64_T endTime;
    UINT_T size;
    UINT64_T startOffset;
    INT_T jpgNum;       //图片数量
    INT_T IframeNum;    //I帧个数
}STOR_HD_EVENT_FRAGMENT;
typedef struct{
    INT_T cnt;  //event num
    STOR_HD_EVENT_FRAGMENT eventArr[0];
}STOR_HD_SEARCH_BY_DAY;

//define for custom stor pic in hdd
typedef struct {
    STOR_HD_EVENT_TYPE_E type;
    BYTE_T    *buff;
    UINT_T    buffLen;
    UINT64_T  timestamp;
}STOR_HD_PIC_INFO_T;

OPERATE_RET tuya_ipc_search_init(PVOID_T *param);

OPERATE_RET tuya_ipc_search_by_dev(IN CHAR_T * devId, OUT PVOID_T * pOut);

OPERATE_RET tuya_ipc_search_by_type(IN CHAR_T * devId, IN INT_T type, OUT PVOID_T * pOut);

OPERATE_RET tuya_ipc_search_by_day(IN CHAR_T * devId, INT_T year, INT_T month, INT_T day,OUT PVOID_T * pOut);

OPERATE_RET tuya_ipc_search_by_mouth(IN CHAR_T * devId, INT_T year, INT_T month, OUT UINT_T *pDays);

OPERATE_RET tuya_ipc_search_create_handle(IN CHAR_T * devId,OUT PVOID_T * pHandle);

OPERATE_RET tuya_ipc_search_get_nxt_seg(PVOID_T pHandle, STOR_HD_EVENT_FRAGMENT * seg);

OPERATE_RET tuya_ipc_search_seek_frame(PVOID_T pHandle ,STOR_HD_EVENT_FRAGMENT * seg, INT_T type, UINT64_T tims_ms);

//type -1  get frame by node
OPERATE_RET tuya_ipc_search_get_nxt_frame(PVOID_T pHandle, INT_T type, OUT CHAR_T * buff, IN OUT INT_T * len);

OPERATE_RET tuya_ipc_search_release_handle(PVOID_T pHandle);

//do format
OPERATE_RET tuya_ipc_stor_format(STOR_HD_INIT_INFO_T *param);

OPERATE_RET tuya_ipc_stor_get_volume(STOR_HD_INIT_INFO_T *param, OUT UINT64_T * pTotol, OUT UINT64_T * pFree);

#ifdef __cplusplus
}
#endif

#endif

